
// Included with this defition the header includes the actual functions.
// Without it is just declares them, so we have to include once like this
// to actually be able to access OpenGL.
#define GLAD_GL_IMPLEMENTATION
#include "glad/gl.h"
