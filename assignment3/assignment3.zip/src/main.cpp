
#include "app.h"

//------------------------------------------------------------------------

int main()
{
    App* app = new App;
    app->run();
    return 0;
}

